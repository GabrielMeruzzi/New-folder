
            if item[0] != i[0]:
                dicUp[item[0]] = item[1]
            elif i[0] != item[0]:
                dicUp[item[0]] = item[1]